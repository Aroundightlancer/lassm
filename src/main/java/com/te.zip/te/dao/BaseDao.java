package com.te.dao;

public interface BaseDao {
}
