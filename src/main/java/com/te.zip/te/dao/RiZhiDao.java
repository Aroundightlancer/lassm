package com.te.dao;

import com.te.model.RiZhi;

public interface RiZhiDao extends CrudDao<RiZhi> {
}
