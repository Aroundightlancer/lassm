package com.te.model;

public class Menu extends Entity {

    private Integer parentId; //父级编号
    private String name;   //页面显示的菜单名称
    private String icon;  //图标url
    private String url;   //跳转路径的url
    private Integer userType; //1子女，2亲属，3朋友
    private Integer menuId; //页面的id号
    public Integer getMenuId()
    {
        return menuId;
    }
    public void setMenuId(Integer menuId)
    {
        this.menuId=menuId;
    }
    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon == null ? null : icon.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }
}