package com.te.model.constant;

public class OldPeopleHobbyOperationCode {

    public static final Integer HOBBY_INFOMATION = 1100;
    public static final Integer ADD_NEW_HOBBY_INFOMATION = 1101;
    public static final Integer UPDATE_NEW_HOBBY_INFOMATION = 1102;
    public static final Integer DELETE_NEW_HOBBY_INFOMATION = 1103;

}
