package com.te.model.constant;

public class FriendCycleOperationCode {

    private static final Integer FRIEND_CYCLE = 1200;
    private static final Integer PUBLISH_FRIEND_CYCLE = 1201;
    private static final Integer COMMENT_FRIEND_CYCLE = 1202;
    private static final Integer REPOST_FRIEND_CYCLE = 1203;
    private static final Integer PRAISE_FRIEND_CYCLE = 1204;

}
