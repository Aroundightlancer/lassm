package com.te.model.constant;

public class OldPeopleAllergyOperationCode {

    public static final Integer ALLERGY_INFOMATION = 1000;
    public static final Integer ADD_NEW_ALLERGY_INFOMATION = 1001;
    public static final Integer UPDATE_NEW_ALLERGY_INFOMATION = 1002;
    public static final Integer DELETE_NEW_ALLERGY_INFOMATION = 1003;

}
